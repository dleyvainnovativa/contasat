@extends('layouts.app')
@section('title', 'Facturas · ContaSAT')

@section('content')
<div class="page-head" data-reveal>
    <div>
        <h1>Facturas</h1>
        <div class="subtitle">{{ $period->client->display_name }} · {{ $period->label }}</div>
    </div>
    <button class="btn btn-brand btn-icon" onclick="App.modal.show('upload-modal')">
        <i class="fa-solid fa-cloud-arrow-up"></i> Cargar CFDI
    </button>
</div>

{{-- Totals strip: emitidas (income) vs recibidas (expense). Hidden via config. --}}
@if(config('contasat.show_header_cards'))
<div class="row g-3 mb-4">
    <div class="col-sm-4" data-reveal>
        <div class="stat-card">
            <span class="stat-card__label"><i class="fa-solid fa-arrow-up-right-dots" style="color:var(--ok)"></i> Ingresos (emitidas)</span>
            <span class="stat-card__value">${{ number_format($totals['emitidas'], 2) }}</span>
        </div>
    </div>
    <div class="col-sm-4" data-reveal data-reveal-delay="40">
        <div class="stat-card">
            <span class="stat-card__label"><i class="fa-solid fa-arrow-down-right-dots" style="color:var(--warn)"></i> Gastos (recibidas)</span>
            <span class="stat-card__value">${{ number_format($totals['recibidas'], 2) }}</span>
        </div>
    </div>
    <div class="col-sm-4" data-reveal data-reveal-delay="80">
        <div class="stat-card">
            <span class="stat-card__label"><i class="fa-solid fa-file-lines" style="color:var(--brand-500)"></i> Total de facturas</span>
            <span class="stat-card__value">{{ $totals['count'] }}</span>
        </div>
    </div>
</div>
@endif

{{-- Recent uploads (shows async progress) --}}
@if($recentUploads->isNotEmpty())
    <div class="card-clean mb-4" data-reveal id="uploads-panel">
        <div class="card-clean__head"><strong>Cargas recientes</strong></div>
        <div class="card-clean__body" style="padding-top:.5rem; padding-bottom:.5rem;">
            @foreach($recentUploads as $up)
                <div class="d-flex align-items-center gap-3 py-2" data-upload-row="{{ $up->id }}" style="border-bottom:1px solid var(--border);">
                    <i class="fa-solid fa-file-zipper text-muted"></i>
                    <div class="flex-grow-1" style="min-width:0;">
                        <div class="text-truncate" style="font-size:13.5px; font-weight:500;">{{ $up->original_name }}</div>
                        <div class="text-muted" style="font-size:12px;" data-upload-detail>
                            @if($up->status === 'done')
                                {{ $up->imported }} importadas · {{ $up->skipped }} omitidas @if($up->failed) · {{ $up->failed }} con error @endif
                            @elseif($up->status === 'failed')
                                {{ $up->fatal_error }}
                            @else
                                En proceso…
                            @endif
                        </div>
                        @if($up->status === 'done' && !empty($up->errors))
                            <details style="margin-top:.25rem;">
                                <summary style="font-size:11.5px; color:var(--text-muted); cursor:pointer;">
                                    Ver detalle de omitidas / errores ({{ count($up->errors) }})
                                </summary>
                                <ul style="margin:.35rem 0 0; padding-left:1.1rem; font-size:11.5px; color:var(--text-muted);">
                                    @foreach($up->errors as $line)
                                        <li class="text-truncate" title="{{ $line }}">{{ $line }}</li>
                                    @endforeach
                                </ul>
                            </details>
                        @endif
                    </div>
                    <span class="badge-status s-{{ $up->statusColor() }}" data-upload-badge>
                        <i class="fa-solid fa-circle" style="font-size:8px;"></i> {{ $up->statusLabel() }}
                    </span>
                </div>
            @endforeach
        </div>
    </div>
@endif
           @php
    $filtros = [
        ''              => 'Todas',
        'ingreso'       => 'Ingreso',
        'gasto'         => 'Gastos',
        'nomina'        => 'Nómina',
        'pago_emitido'  => 'Pago emitidos',
        'pago_recibido' => 'Pago recibidos',
    ];
    $activo = request('filtro', '');
@endphp
<div class="fac-tabs" data-reveal>
    @foreach($filtros as $key => $label)
        <a href="{{ route('invoices.index', array_filter(['filtro' => $key])) }}"
           class="fac-tab {{ $activo === $key ? 'active' : '' }}">
            {{ $label }}
            @if(($navCounts[$key] ?? 0) > 0)
            <span class="fac-tab__count">{{ $navCounts[$key] }}</span>
            @endif
        </a>
    @endforeach
</div>
{{-- Invoice table --}}
<div class="card-clean" data-reveal>
    <div class="card-clean__head">
        <form method="GET" action="{{ route('invoices.index') }}" class="d-flex align-items-center gap-2 w-100">
            <div class="position-relative flex-grow-1" style="max-width:340px;">
                <i class="fa-solid fa-magnifying-glass position-absolute text-muted" style="left:.75rem; top:50%; transform:translateY(-50%); font-size:13px;"></i>
                <input type="search" name="q" value="{{ $q }}" class="form-control" placeholder="RFC, nombre, folio o UUID" style="padding-left:2.25rem;">
            </div>
            <select name="tipo" class="form-select" style="width:auto;" onchange="this.form.submit()">
                <option value="">Todas</option>
                <option value="emitida" @selected($tipo === 'emitida')>Emitidas</option>
                <option value="recibida" @selected($tipo === 'recibida')>Recibidas</option>
            </select>
        </form>
    </div>

    {{-- Every filtro renders a purpose-built wide table; each partial brings its
         own scroll wrapper, pagination and (where relevant) modals. Todas and
         Ingreso use the ingreso layout; the rest their own. --}}
    @php
        $wideMap = [
            ''              => 'invoices._ingreso_wide',
            'ingreso'       => 'invoices._ingreso_wide',
            'gasto'         => 'invoices._gasto_wide',
            'nomina'        => 'invoices._nomina_wide',
            'pago_emitido'  => 'invoices._pago_wide',
            'pago_recibido' => 'invoices._pago_wide',
        ];
        $widePartial = $wideMap[$filtro ?? ''] ?? 'invoices._ingreso_wide';
    @endphp
    @if($invoices->isEmpty() && ($filtro ?? '') === '')
        <div class="empty-state">
            <i class="fa-solid fa-file-circle-plus"></i>
            <h3>Sin facturas</h3>
            <p>Carga un ZIP de CFDI descargado del SAT para empezar.</p>
            <button class="btn btn-brand btn-icon mt-2" onclick="App.modal.show('upload-modal')">
                <i class="fa-solid fa-cloud-arrow-up"></i> Cargar CFDI
            </button>
        </div>
    @else
        <div class="p-2">
            @include($widePartial)
        </div>
    @endif
</div>

@if(in_array($filtro ?? '', ['pago_emitido', 'pago_recibido'], true))
    @include('invoices._pago_detail')
@endif

@include('invoices._upload_modal')
@endsection

@push('scripts')
<script>
// Upload flow: submit file -> poll status -> refresh list when done.
(function () {
    const form = document.getElementById('upload-form');
    const fileInput = document.getElementById('cfdi-file');
    const dropzone = document.getElementById('dropzone');
    const submitBtn = document.getElementById('upload-submit');
    const fileLabel = document.getElementById('file-label');

    if (!form) return;

    // Dropzone interactions
    dropzone.addEventListener('click', () => fileInput.click());
    ['dragover', 'dragenter'].forEach(ev => dropzone.addEventListener(ev, (e) => {
        e.preventDefault(); dropzone.classList.add('dragging');
    }));
    ['dragleave', 'drop'].forEach(ev => dropzone.addEventListener(ev, (e) => {
        e.preventDefault(); dropzone.classList.remove('dragging');
    }));
    dropzone.addEventListener('drop', (e) => {
        if (e.dataTransfer.files.length) { fileInput.files = e.dataTransfer.files; updateLabel(); }
    });
    fileInput.addEventListener('change', updateLabel);

    function updateLabel() {
        fileLabel.textContent = fileInput.files.length ? fileInput.files[0].name : 'Arrastra un ZIP o XML, o haz clic para elegir';
    }

    submitBtn.addEventListener('click', async () => {
        if (!fileInput.files.length) { App.toast.warning('Elige un archivo primero.'); return; }

        const fd = new FormData();
        fd.append('archivo', fileInput.files[0]);

        await App.loading.button(submitBtn, async () => {
            try {
                const res = await App.http.post('{{ route('invoices.upload') }}', fd);
                App.toast.info(res.message || 'Procesando…');
                App.modal.hide('upload-modal');
                pollStatus(res.upload_id);
            } catch (err) {
                App.toast.error(err.message || 'No se pudo cargar el archivo.');
            }
        });
    });

    async function pollStatus(id) {
        const url = '{{ url('invoices/uploads') }}/' + id + '/status';
        let tries = 0;
        const timer = setInterval(async () => {
            tries++;
            try {
                const s = await App.http.get(url);
                if (s.finished) {
                    clearInterval(timer);
                    if (s.status === 'done') {
                        App.toast.success(`${s.imported} importadas, ${s.skipped} omitidas` + (s.failed ? `, ${s.failed} con error` : ''));
                        setTimeout(() => window.location.reload(), 1200);
                    } else {
                        App.toast.error(s.fatal || 'La carga falló.');
                    }
                }
            } catch (e) { /* keep polling */ }
            if (tries > 150) clearInterval(timer); // ~5 min ceiling
        }, 2000);
    }
})();
</script>
@endpush