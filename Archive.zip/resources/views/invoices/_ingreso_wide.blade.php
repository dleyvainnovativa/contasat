{{-- Wide income detail table (formerly the provision-ingresos page), now the
     ingreso tab body. Adds a "show invoice" action alongside Provisión (opens the
     classify modal) and Cobro (opens the Asiento de cobro modal). Expects the
     same $invoices / $q / $perPage the filtered view provides. --}}
<style>
    .pi-wrap { border:1px solid var(--border); border-radius:var(--radius-lg); overflow:auto; background:var(--surface); max-height:72vh; }
    .pi-table { border-collapse:separate; border-spacing:0; font-size:12px; white-space:nowrap; min-width:100%; }
    .pi-table th, .pi-table td { padding:.5rem .6rem; border-bottom:1px solid var(--border); text-align:left; }
    .pi-table thead th {
        position:sticky; top:0; z-index:2; background:var(--surface-2);
        font-weight:600; font-size:11px; text-transform:uppercase; letter-spacing:.02em;
        color:var(--text-muted); border-bottom:2px solid var(--border);
    }
    .pi-table tbody tr:hover { background:var(--surface-2); }
    .pi-num { text-align:right; font-variant-numeric:tabular-nums; }
    .pi-table tfoot td { position:sticky; bottom:0; z-index:2; background:var(--surface-2); border-top:2px solid var(--border); font-weight:650; }
    .pi-muted { color:var(--text-muted); }
    .pi-trunc { max-width:190px; overflow:hidden; text-overflow:ellipsis; }
    .pi-group-16 { background:color-mix(in srgb, var(--brand-050) 40%, transparent); }
    [data-theme="dark"] .pi-group-16 { background:color-mix(in srgb, var(--surface-2) 60%, transparent); }
    .pi-btn-xs { font-size:11px; padding:.2rem .5rem; }
    .pi-ref { font-weight:600; color:var(--ok); }
    .pi-col-uuid { max-width:150px; overflow:hidden; text-overflow:ellipsis; }
    /* Foreign-currency cells: MXN conversion primary, original subtle underneath. */
    .pi-fx { font-size:10px; color:var(--text-muted); line-height:1.1; margin-top:1px; font-variant-numeric:tabular-nums; }
    .pi-doc-rel { color:var(--brand-600); font-weight:600; }
    [data-theme="dark"] .pi-doc-rel { color:var(--brand-300, var(--brand)); }
</style>

@if($invoices->isEmpty())
<div class="empty-state">
    <i class="fa-solid fa-file-invoice"></i>
    <h3>Sin facturas</h3>
    <p>No hay comprobantes de ingreso en el periodo.</p>
</div>
@else
<div class="pi-wrap">
    <table class="pi-table">
        <thead>
            <tr>
                <th style="width:1%;">Acciones</th>
                <th>Documento</th>
                <th>Estado SAT</th>
                <th>Fecha</th>
                <th>Folio</th>
                <th>UUID</th>
                <th>RFC Receptor</th>
                <th>Nombre Receptor</th>
                <th class="pi-num pi-group-16">Ing. Base 16%</th>
                <th class="pi-num">Ing. Base 0%</th>
                <th class="pi-num">Ing. Exento</th>
                <th class="pi-num">Ing. No Objeto</th>
                <th class="pi-num">Subtotal</th>
                <th class="pi-num">IVA</th>
                <th class="pi-num">Otros Imp.</th>
                <th class="pi-num">IVA Ret.</th>
                <th class="pi-num">ISR Ret.</th>
                <th class="pi-num">Descuento</th>
                <th class="pi-num">Total</th>
                <th>Uso CFDI</th>
                <th>Concepto XML</th>
                <th>Forma Pago</th>
                <th>Método Pago</th>
                <th>Recibo Pago</th>
                <th>Fecha Pago</th>
                <th class="pi-num">Importe Pago</th>
                <th>Cta Pago</th>
            </tr>
        </thead>
        <tbody>
            @foreach($invoices as $inv)
                @php
                    $base = $inv->iva_base_breakdown;
                    $pago = $inv->pago_resumen;

                    // Row sign: notas de crédito (tipo E) display negative and subtract.
                    $signo = $inv->signo;

                    // Money cell renderer. Values arrive in the invoice's currency.
                    // For non-MXN invoices the MXN conversion is shown as primary
                    // (value × tipo de cambio) with the original amount + code as a
                    // subtle line beneath. Nota de crédito amounts are negated.
                    // Returns HTML (numeric-only, safe to echo).
                    $money = function ($v, bool $muted = false) use ($inv, $signo) {
                        if ($v === null || $v === '') {
                            return '<span class="pi-muted">—</span>';
                        }
                        $foreign = $inv->es_moneda_extranjera;
                        $primaryVal = ($foreign ? $inv->aMxn($v) : (float) $v) * $signo;
                        $mutedCls = $muted ? ' pi-muted' : '';
                        $html = '<span class="' . trim('pi-mxn' . $mutedCls) . '">$' . number_format($primaryVal, 2) . '</span>';
                        if ($foreign) {
                            $html .= '<div class="pi-fx">' . e(strtoupper($inv->moneda)) . ' ' . number_format((float) $v * $signo, 2) . '</div>';
                        }
                        return $html;
                    };
                @endphp
                <tr data-invoice="{{ $inv->id }}">
                    <td style="white-space:nowrap;">
                        <div class="d-flex align-items-center gap-1">
                            {{-- Show invoice --}}
                            <a href="{{ route('invoices.show', $inv) }}" class="btn btn-soft pi-btn-xs" title="Ver factura">
                                <i class="fa-solid fa-eye"></i>
                            </a>
                            @if($inv->es_nota_credito)
                                {{-- Notas de crédito reduce the related ingreso; they don't get their own póliza. --}}
                                <span class="badge-status s-warning" style="font-size:10px;" title="Nota de crédito — resta, no genera póliza">NC</span>
                            @else
                            {{-- Provisión: ref if generated, else opens classify modal --}}
                            @if($inv->provision_ref)
                                <span class="pi-ref" title="Provisión generada">{{ $inv->provision_ref }}</span>
                            @else
                                <button class="btn btn-brand pi-btn-xs" data-classify="{{ $inv->id }}" title="Clasificar y generar provisión">
                                    <i class="fa-solid fa-pen"></i>
                                </button>
                            @endif
                            {{-- Cobro: ref if generated, else opens cobro modal --}}
                            @if($inv->ingreso_ref)
                                <span class="pi-ref" title="Cobro generado">{{ $inv->ingreso_ref }}</span>
                            @else
                                <button class="btn btn-soft pi-btn-xs" data-cobro="{{ $inv->id }}"
                                    data-folio="{{ $inv->serie }}{{ $inv->folio }}"
                                    data-total="{{ $inv->total }}"
                                    {{ $inv->provision_ref ? '' : 'disabled title=Genera-primero-la-provisión' }}>
                                    <i class="fa-solid fa-money-bill-wave"></i>
                                </button>
                            @endif
                            @endif
                        </div>
                    </td>
                    <td>
                        @if($inv->tipo_relacion)
                            <span class="pi-doc-rel" title="Tipo de relación {{ $inv->tipo_relacion }}">{{ $inv->documento_label }}</span>
                        @else
                            {{ $inv->documento_label }}
                        @endif
                    </td>
                    <td>
                        <span class="badge-status {{ $inv->cancelado ? 's-danger' : 's-success' }}" style="font-size:10.5px;">
                            {{ $inv->estado_sat }}
                        </span>
                    </td>
                    <td class="data">{{ optional($inv->fecha_emision)->format('Y-m-d') }}</td>
                    <td class="data">{{ $inv->serie }}{{ $inv->folio }}</td>
                    <td class="data pi-col-uuid" title="{{ $inv->uuid }}">{{ $inv->uuid }}</td>
                    <td class="data">{{ $inv->receptor_rfc }}</td>
                    <td class="pi-trunc" title="{{ $inv->receptor_nombre }}">{{ $inv->receptor_nombre }}</td>
                    <td class="pi-num pi-group-16">{!! $money($base['16']) !!}</td>
                    <td class="pi-num">{!! $money($base['0']) !!}</td>
                    <td class="pi-num">{!! $money($base['exento']) !!}</td>
                    <td class="pi-num">{!! $money($base['no_objeto']) !!}</td>
                    <td class="pi-num">{!! $money($inv->subtotal_neto) !!}</td>
                    <td class="pi-num">{!! $money($inv->iva_trasladado) !!}</td>
                    <td class="pi-num pi-muted">{!! abs($inv->otros_impuestos) > 0.005 ? $money($inv->otros_impuestos, true) : '—' !!}</td>
                    <td class="pi-num">{!! $money($inv->iva_retenido) !!}</td>
                    <td class="pi-num">{!! $money($inv->isr_retenido) !!}</td>
                    <td class="pi-num pi-muted">{!! (float) $inv->descuento > 0.005 ? $money($inv->descuento, true) : '—' !!}</td>
                    <td class="pi-num">{!! $money($inv->total) !!}</td>
                    <td class="pi-trunc" title="{{ $inv->uso_cfdi_label }}">{{ $inv->uso_cfdi_label ?: '—' }}</td>
                    <td class="pi-trunc" title="{{ $inv->conceptos_resumen }}">{{ \Illuminate\Support\Str::limit($inv->conceptos_resumen, 40) ?: '—' }}</td>
                    <td class="data">{{ $inv->forma_pago ?: '—' }}</td>
                    <td class="data">{{ $inv->metodo_pago ?: '—' }}</td>
                    <td>
                        <div style="display:flex; flex-direction:column; gap:3px; align-items:flex-start;">
                        @forelse($inv->pago_comp_refs as $c)
                            @if($c['id'])
                            <a href="{{ route('invoices.show', $c['id']) }}" class="pi-ref" title="Ver complemento de pago" style="text-decoration:none;">
                                {{ $c['folio'] ?? 'CEP' }} — {{ $c['fecha'] ?? '—' }} <i class="fa-solid fa-up-right-from-square" style="font-size:9px;"></i>
                            </a>
                            @else
                            <span class="pi-ref">{{ $c['folio'] ?? 'CEP' }} — {{ $c['fecha'] ?? '—' }}</span>
                            @endif
                        @empty
                            <span class="pi-muted">—</span>
                        @endforelse
                        </div>
                    </td>
                    <td class="data">{{ $pago['fecha'] ?? '—' }}</td>
                    <td class="pi-num">{!! $money($pago['importe']) !!}</td>
                    <td class="data pi-muted">{{ $pago['recibo'] ? '102.01' : '—' }}</td>
                </tr>
            @endforeach
        </tbody>
        @isset($footerTotals)
        <tfoot>
            <tr>
                <td colspan="8" style="text-align:right;">Totales · {{ $footerTotals['count'] }} facturas</td>
                <td class="pi-num">${{ number_format($footerTotals['base16'], 2) }}</td>
                <td class="pi-num">${{ number_format($footerTotals['base0'], 2) }}</td>
                <td class="pi-num">${{ number_format($footerTotals['exento'], 2) }}</td>
                <td class="pi-num">${{ number_format($footerTotals['no_objeto'], 2) }}</td>
                <td class="pi-num">${{ number_format($footerTotals['subtotal'], 2) }}</td>
                <td class="pi-num">${{ number_format($footerTotals['iva'], 2) }}</td>
                <td class="pi-num">${{ number_format($footerTotals['otros'], 2) }}</td>
                <td class="pi-num">${{ number_format($footerTotals['iva_ret'], 2) }}</td>
                <td class="pi-num">${{ number_format($footerTotals['isr_ret'], 2) }}</td>
                <td class="pi-num">${{ number_format($footerTotals['descuento'], 2) }}</td>
                <td class="pi-num">${{ number_format($footerTotals['total'], 2) }}</td>
                <td></td><td></td><td></td><td></td><td></td><td></td>
                <td class="pi-num">${{ number_format($footerTotals['importe_pago'], 2) }}</td>
                <td></td>
            </tr>
        </tfoot>
        @endisset
    </table>
</div>

<div class="d-flex align-items-center justify-content-between mt-3 flex-wrap gap-2">
    <div class="d-flex align-items-center gap-2">
        <label class="pi-muted" style="font-size:12.5px;">Mostrar</label>
        <select class="form-select form-select-sm" style="width:auto;" onchange="
            const u = new window.URL(window.location.href);
            u.searchParams.set('per_page', this.value);
            u.searchParams.delete('page');
            window.location = u.toString();
        ">
            @foreach([25, 100, 200, 500] as $opt)
                <option value="{{ $opt }}" @selected(($perPage ?? 25) === $opt)>{{ $opt }}</option>
            @endforeach
        </select>
        <span class="pi-muted" style="font-size:12.5px;">por página</span>
    </div>
    <div>{{ $invoices->links() }}</div>
</div>
@endif

{{-- Classify modal (Provisión buttons) --}}
@include('invoices._classify_modal')

{{-- Asiento de cobro modal --}}
<div class="modal fade" id="cobro-modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content" style="border-radius:var(--radius-lg); border-color:var(--border); background:var(--surface);">
            <div class="modal-body p-4">
                <h5 class="mb-1" style="font-weight:600;">Asiento de cobro</h5>
                <p class="text-muted mb-3" style="font-size:13px;">
                    <span id="cb-folio" class="data"></span> · <span id="cb-total"></span>
                </p>
                <div class="mb-3">
                    <label class="form-label">Fecha de pago</label>
                    <input type="date" id="cb-fecha" class="form-control">
                    <div class="form-hint" style="font-size:11.5px;">
                        Genera la póliza de cobro: Debe 102.01 bancos / Haber 105.01.# cliente,
                        más la reclasificación de IVA 209.01 → 208.01.
                    </div>
                </div>
                <div class="d-flex justify-content-end gap-2 mt-4">
                    <button class="btn btn-soft" data-bs-dismiss="modal">Cancelar</button>
                    <button class="btn btn-brand btn-icon" id="cb-submit">
                        <i class="fa-solid fa-check"></i> Generar cobro
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

@push('scripts')
<script type="module">
    (function () {
        const base = @json(url('invoices'));
        let cobroId = null;

        document.querySelectorAll('[data-cobro]').forEach(btn => {
            btn.addEventListener('click', () => {
                cobroId = btn.dataset.cobro;
                document.getElementById('cb-folio').textContent = btn.dataset.folio || '—';
                document.getElementById('cb-total').textContent =
                    '$' + Number(btn.dataset.total || 0).toLocaleString('es-MX', { minimumFractionDigits: 2 });
                document.getElementById('cb-fecha').value = new Date().toISOString().slice(0, 10);
                App.modal.show('cobro-modal');
            });
        });

        const submit = document.getElementById('cb-submit');
        submit?.addEventListener('click', async () => {
            const fecha = document.getElementById('cb-fecha').value;
            if (!fecha) { App.toast.warning('Ingresa la fecha de pago.'); return; }
            await App.loading.button(submit, async () => {
                try {
                    const res = await App.http.post(`${base}/${cobroId}/cobro`, { origen: 'manual', fecha_pago: fecha });
                    App.toast.success(res.message);
                    App.modal.hide('cobro-modal');
                    setTimeout(() => window.location.reload(), 900);
                } catch (e) { App.toast.error(e.message); }
            });
        });
    })();
</script>
@endpush
