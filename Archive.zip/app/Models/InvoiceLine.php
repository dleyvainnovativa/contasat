<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/** A concepto line of a CFDI invoice. Populated in Phase 1. */
class InvoiceLine extends Model
{
    protected $fillable = [
        'invoice_id',
        'clave_prod_serv',
        'no_identificacion',
        'descripcion',
        'cantidad',
        'clave_unidad',
        'valor_unitario',
        'importe',
        'descuento',
        'iva_trasladado',
        'iva_retenido',
        'isr_retenido',
        'iva_base_tipo',
        'cuenta_abono_id',
        'parte_no_deducible',
    ];

    protected function casts(): array
    {
        return [
            'cantidad'           => 'decimal:6',
            'valor_unitario'     => 'decimal:6',
            'importe'            => 'decimal:2',
            'descuento'          => 'decimal:2',
            'iva_trasladado'     => 'decimal:2',
            'iva_retenido'       => 'decimal:2',
            'isr_retenido'       => 'decimal:2',
            'parte_no_deducible' => 'decimal:2',
        ];
    }

    public function invoice(): BelongsTo
    {
        return $this->belongsTo(Invoice::class);
    }

    /** Per-line abono account override; null = use the invoice-level account. */
    public function cuentaAbono(): BelongsTo
    {
        return $this->belongsTo(\App\Models\Account::class, 'cuenta_abono_id');
    }
}
