<?php

namespace App\Http\Controllers;

use App\Models\Invoice;
use App\Services\InvoiceTableTotals;
use App\Services\WorkContext;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;

/**
 * The Facturas submenu (Block B) — five filtered views over the same invoice
 * data, keyed on CFDI tipo_comprobante and direction:
 *
 *   ingreso   -> tipo_comprobante I, emitida  (client's income)
 *   gasto     -> tipo_comprobante I, recibida (client's expense)
 *   nomina    -> tipo_comprobante N
 *   pago_emitido   -> tipo_comprobante P, emitida
 *   pago_recibido  -> tipo_comprobante P, recibida
 *
 * These are slices, not new storage — everything filters the invoices table the
 * Phase 1 ingest already populates. Tax totals (iva_trasladado, iva_retenido,
 * isr_retenido) are denormalized onto the invoice at ingest, so list queries read
 * them directly rather than aggregating lines on every request.
 */
class InvoiceViewController extends Controller
{
    /**
     * view key => [label, tipo_comprobante[], direction|null]
     *
     * Ingreso and gasto span tipo I (facturas) and tipo E (notas de crédito):
     * a credit note belongs with the income/expense it reduces, shown as a
     * negative row and subtracted from the totals.
     */
    private const VIEWS = [
        'ingreso'       => ['Provisión facturas de ingreso', ['I', 'E'], 'emitida'],
        'gasto'         => ['Provisión facturas de gastos',  ['I', 'E'], 'recibida'],
        'nomina'        => ['Provisión facturas de nómina',  ['N'], null],
        'pago_emitido'  => ['Complementos de pago emitidos', ['P'], 'emitida'],
        'pago_recibido' => ['Complementos de pago recibidos', ['P'], 'recibida'],
    ];

    public function __construct(
        private readonly WorkContext $context,
    ) {}

    public function show(Request $request, string $view): View|RedirectResponse
    {
        if (! isset(self::VIEWS[$view])) {
            abort(404);
        }

        if (! $this->context->hasPeriod()) {
            return redirect()->route('dashboard')
                ->with('toast', ['type' => 'warning', 'message' => 'Selecciona un cliente y periodo primero.']);
        }

        [$label, $tipos, $direction] = self::VIEWS[$view];
        $tipoComprobante = $tipos[0];
        $period = $this->context->period();

        $search = function ($q) use ($request) {
            $term = $request->string('q')->toString();
            $q->where(fn($s) => $s->where('folio', 'like', "%{$term}%")
                ->orWhere('uuid', 'like', "%{$term}%")
                ->orWhere('receptor_nombre', 'like', "%{$term}%")
                ->orWhere('emisor_nombre', 'like', "%{$term}%")
                ->orWhere('receptor_rfc', 'like', "%{$term}%")
                ->orWhere('emisor_rfc', 'like', "%{$term}%"));
        };

        $query = Invoice::where('period_id', $period->id)
            ->whereIn('tipo_comprobante', $tipos)
            ->when($direction, fn($q) => $q->where('tipo', $direction))
            ->when($request->filled('q'), $search)
            ->with(['cuentaContable', 'cuentaAbono'])
            // Concepts column shows only on ingreso/gasto (I-type, non-nómina).
            // Eager-load line descriptions there to build conceptos_resumen without N+1.
            ->when($tipoComprobante === 'I', fn($q) => $q->with('lines:id,invoice_id,descripcion'))
            // Ingreso renders the wide detail table: it also needs the IVA-base
            // buckets, existing pólizas (Dr/Ig refs), and the CEP payment block.
            ->when($view === 'ingreso', fn($q) => $q->with([
                'lines:id,invoice_id,descripcion,importe,iva_trasladado,iva_base_tipo',
                'polizas:id,invoice_id,tipo,num_iden',
                'paymentDocuments:id,iddocumento,payment_invoice_id,fecha_pago,imp_pagado',
                'paymentDocuments.paymentInvoice:id,serie,folio',
            ]))
            // Gasto renders the wide egreso table: base buckets + non-deducible,
            // gasto pólizas (provisión/pago refs), and the CEP payment block.
            ->when($view === 'gasto', fn($q) => $q->with([
                'lines:id,invoice_id,descripcion,importe,iva_trasladado,iva_base_tipo,parte_no_deducible',
                'polizas:id,invoice_id,tipo,num_iden',
                'paymentDocuments:id,iddocumento,payment_invoice_id,fecha_pago,imp_pagado',
                'paymentDocuments.paymentInvoice:id,serie,folio',
            ]))
            // Nómina wide table: contable account (601.01) + CEP refs.
            ->when($view === 'nomina', fn($q) => $q->with([
                'paymentDocuments:id,iddocumento,payment_invoice_id,fecha_pago,imp_pagado',
                'paymentDocuments.paymentInvoice:id,serie,folio',
            ]))
            // Pago wide table: the issued DoctoRelacionado links it settles.
            ->when(in_array($view, ['pago_emitido', 'pago_recibido'], true), fn($q) => $q->with([
                'issuedPayments:id,payment_invoice_id,fecha_pago,forma_pago,moneda,monto_pago,num_operacion,imp_pagado,paid_invoice_id',
            ]))
            ->orderByDesc('fecha_emision');

        // Every view is now a wide table with a selectable page size.
        $perPage = $this->perPage($request);
        $invoices = $query->paginate($perPage)->withQueryString();

        // Totals for the filtered set (whole period, not just the page). Notas de
        // crédito (tipo E) subtract; subtotal uses the net amount (subtotal −
        // descuento) to match the displayed Subtotal column.
        $row = Invoice::where('period_id', $period->id)
            ->whereIn('tipo_comprobante', $tipos)
            ->when($direction, fn($q) => $q->where('tipo', $direction))
            ->selectRaw("count(*) as cnt,
                sum(case when tipo_comprobante = 'E' then -(subtotal - descuento) else (subtotal - descuento) end) as subtotal,
                sum(case when tipo_comprobante = 'E' then -iva_trasladado else iva_trasladado end) as iva,
                sum(case when tipo_comprobante = 'E' then -total else total end) as total")
            ->first();

        $totals = [
            'count'    => (int) ($row->cnt ?? 0),
            'subtotal' => (float) ($row->subtotal ?? 0),
            'iva'      => (float) ($row->iva ?? 0),
            'total'    => (float) ($row->total ?? 0),
        ];

        // Footer column totals over the whole filtered set (#6), matching the
        // visible columns of whichever wide table this view renders.
        $footerTotals = InvoiceTableTotals::compute(
            Invoice::where('period_id', $period->id)
                ->whereIn('tipo_comprobante', $tipos)
                ->when($direction, fn($q) => $q->where('tipo', $direction))
                ->when($request->filled('q'), $search),
            $view
        );

        return view('invoices.filtered', [
            'view'      => $view,
            'label'     => $label,
            'isPago'    => $tipoComprobante === 'P',
            'isNomina'  => $tipoComprobante === 'N',
            'invoices'  => $invoices,
            'totals'    => $totals,
            'period'    => $period,
            'q'         => $request->string('q')->toString(),
            'navItems'  => $this->navSummary($period->id),
            'perPage'   => $perPage,
            'footerTotals' => $footerTotals,
        ]);
    }

    /** Rows per page for the wide ingreso table: 25/50/100/200, default 50. */
    private function perPage(Request $request): int
    {
        $allowed = [25, 100, 200, 500];
        $requested = (int) $request->integer('per_page', 25);

        return in_array($requested, $allowed, true) ? $requested : 25;
    }

    /**
     * Per-view counts for the submenu, so each tab can show how many invoices it
     * holds. One grouped query rather than five counts.
     *
     * @return array<string, int>
     */
    private function navSummary(int $periodId): array
    {
        $rows = Invoice::where('period_id', $periodId)
            ->selectRaw('tipo_comprobante, tipo, count(*) as n')
            ->groupBy('tipo_comprobante', 'tipo')
            ->get();

        $counts = [];
        foreach (self::VIEWS as $key => [$label, $tipos, $dir]) {
            $counts[$key] = $rows
                ->whereIn('tipo_comprobante', $tipos)
                ->when($dir, fn($c) => $c->where('tipo', $dir))
                ->sum('n');
        }

        return $counts;
    }
}
