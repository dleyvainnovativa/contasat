<?php

namespace App\Http\Controllers;

use App\Jobs\ProcessCfdiUpload;
use App\Models\CfdiUpload;
use App\Models\Invoice;
use App\Models\Period;
use App\Services\InvoiceTableTotals;
use App\Services\WorkContext;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use Illuminate\View\View;

class InvoiceController extends Controller
{
    public function __construct(
        private readonly WorkContext $context,
    ) {}

    /**
     * Invoice browser for the active period. Requires an active client + period;
     * otherwise sends the user back to pick one.
     */
    public function index(Request $request): View|RedirectResponse
    {
        if (! $this->context->hasPeriod()) {
            return redirect()
                ->route('dashboard')
                ->with('toast', ['type' => 'warning', 'message' => 'Selecciona un cliente y periodo primero.']);
        }

        $period = $this->context->period();
        $filtro = $request->string('filtro')->toString();

        // Every tab now renders a wide table. Ingreso/gasto/nómina/Todas read the
        // invoice-level relations; pagos read their issued DoctoRelacionado links.
        // ('' is the Todas tab.)
        $wideFiltro = in_array($filtro, ['', 'ingreso', 'gasto', 'nomina'], true);
        $pagoFiltro = in_array($filtro, ['pago_emitido', 'pago_recibido'], true);

        // Base filtered query (period + search + active tab), shared by the
        // paginated list and the footer totals so both see the same set.
        $base = Invoice::where('period_id', $period->id)
            ->when($request->filled('q'), function ($q) use ($request) {
                $term = $request->string('q')->toString();
                $q->where(function ($sub) use ($term) {
                    $sub->where('emisor_nombre', 'like', "%{$term}%")
                        ->orWhere('receptor_nombre', 'like', "%{$term}%")
                        ->orWhere('emisor_rfc', 'like', "%{$term}%")
                        ->orWhere('receptor_rfc', 'like', "%{$term}%")
                        ->orWhere('uuid', 'like', "%{$term}%")
                        ->orWhere('folio', 'like', "%{$term}%")
                        ->orWhereRaw("CONCAT(COALESCE(serie,''), COALESCE(folio,'')) LIKE ?", ["%{$term}%"]);
                });
            })
            ->when($request->filled('filtro'), function ($q) use ($filtro) {
                match ($filtro) {
                    // Ingreso/gasto span facturas (I) and notas de crédito (E).
                    'ingreso'       => $q->whereIn('tipo_comprobante', ['I', 'E'])->where('tipo', 'emitida'),
                    'gasto'         => $q->whereIn('tipo_comprobante', ['I', 'E'])->where('tipo', 'recibida'),
                    'nomina'        => $q->where('tipo_comprobante', 'N'),
                    'pago_emitido'  => $q->where('tipo_comprobante', 'P')->where('tipo', 'emitida'),
                    'pago_recibido' => $q->where('tipo_comprobante', 'P')->where('tipo', 'recibida'),
                    default         => $q,
                };
            });

        $invoices = (clone $base)
            ->when($wideFiltro, fn ($q) => $q->with([
                'cuentaContable', 'cuentaAbono',
                'lines:id,invoice_id,descripcion,importe,iva_trasladado,iva_base_tipo,parte_no_deducible',
                'polizas:id,invoice_id,tipo,num_iden',
                'paymentDocuments:id,iddocumento,payment_invoice_id,fecha_pago,imp_pagado',
                'paymentDocuments.paymentInvoice:id,serie,folio',
            ]))
            ->when($pagoFiltro, fn ($q) => $q->with([
                'issuedPayments:id,payment_invoice_id,fecha_pago,forma_pago,moneda,monto_pago,num_operacion,imp_pagado,paid_invoice_id',
            ]))
            ->orderByDesc('fecha_emision')
            // Per-page selectable up to 200 (default 25). Lets the accountant see
            // a whole period's invoices on one screen when they want to.
            ->paginate($this->perPage($request))
            ->withQueryString();

        // Footer totals over the WHOLE filtered set (#6), not just this page.
        $footerTotals = InvoiceTableTotals::compute(clone $base, $filtro === '' ? 'ingreso' : $filtro);

        // Totals strip (#4): income = facturas emitidas (I) minus notas de crédito
        // emitidas (E); expense = facturas recibidas (I) minus notas recibidas (E).
        // Pagos (P) and nómina (N) are excluded — they aren't income/expense here.
        $signedByDirection = fn (string $direction) => (float) Invoice::where('period_id', $period->id)
            ->where('tipo', $direction)
            ->selectRaw("sum(case when tipo_comprobante = 'I' then total when tipo_comprobante = 'E' then -total else 0 end) as v")
            ->value('v');

        $totals = [
            'emitidas'  => $signedByDirection('emitida'),
            'recibidas' => $signedByDirection('recibida'),
            'count'     => Invoice::where('period_id', $period->id)->count(),
        ];

        $recentUploads = CfdiUpload::where('period_id', $period->id)
            ->latest()
            ->limit(5)
            ->get();

        return view('invoices.index', [
            'period'        => $period,
            'invoices'      => $invoices,
            'totals'        => $totals,
            'recentUploads' => $recentUploads,
            'tipo'          => $request->string('tipo')->toString(),
            'filtro'        => $filtro,
            'q'             => $request->string('q')->toString(),
            'perPage'       => $this->perPage($request),
            'footerTotals'  => $footerTotals,
            'navCounts'     => $this->tabCounts($period->id),
        ]);
    }

    /**
     * Per-type invoice counts for the tab badges (#5), for the whole period
     * regardless of the active tab or search. One grouped query.
     *
     * @return array<string, int>
     */
    private function tabCounts(int $periodId): array
    {
        $rows = Invoice::where('period_id', $periodId)
            ->selectRaw('tipo_comprobante, tipo, count(*) as n')
            ->groupBy('tipo_comprobante', 'tipo')
            ->get();

        $sum = fn (array $types, ?string $dir = null) => (int) $rows
            ->whereIn('tipo_comprobante', $types)
            ->when($dir, fn ($c) => $c->where('tipo', $dir))
            ->sum('n');

        return [
            ''              => (int) $rows->sum('n'),
            'ingreso'       => $sum(['I', 'E'], 'emitida'),
            'gasto'         => $sum(['I', 'E'], 'recibida'),
            'nomina'        => $sum(['N']),
            'pago_emitido'  => $sum(['P'], 'emitida'),
            'pago_recibido' => $sum(['P'], 'recibida'),
        ];
    }

    /** Rows per page for the invoice list: one of 25/100/200/500, default 25. */
    private function perPage(Request $request): int
    {
        $allowed = [25, 100, 200, 500];
        $requested = (int) $request->integer('per_page', 25);

        return in_array($requested, $allowed, true) ? $requested : 25;
    }

    /**
     * Accept a CFDI package (ZIP or single XML), store it, and queue processing.
     * Fast response; the job does the heavy parsing.
     */
    public function upload(Request $request): JsonResponse
    {
        if (! $this->context->hasPeriod()) {
            return response()->json(['message' => 'Selecciona un cliente y periodo primero.'], 422);
        }

        $request->validate([
            'archivo' => ['required', 'file', 'mimes:zip,xml', 'max:51200'], // 50 MB
        ]);

        $period = $this->context->period();
        $client = $this->context->client();

        $file = $request->file('archivo');
        $stored = $file->store("cfdi-uploads/{$client->id}", 'local');

        $upload = CfdiUpload::create([
            'client_id'     => $client->id,
            'period_id'     => $period->id,
            'original_name' => $file->getClientOriginalName(),
            'stored_path'   => $stored,
            'size_bytes'    => $file->getSize(),
            'status'        => 'pending',
        ]);

        ProcessCfdiUpload::dispatch($upload->id);

        return response()->json([
            'ok'        => true,
            'upload_id' => $upload->id,
            'message'   => 'Archivo recibido. Procesando…',
        ]);
    }

    /** Poll endpoint for upload progress (the UI checks this after upload). */
    public function status(CfdiUpload $upload): JsonResponse
    {
        return response()->json([
            'status'   => $upload->status,
            'label'    => $upload->statusLabel(),
            'imported' => $upload->imported,
            'skipped'  => $upload->skipped,
            'failed'   => $upload->failed,
            'errors'   => $upload->errors ?? [],
            'fatal'    => $upload->fatal_error,
            'finished' => $upload->isFinished(),
        ]);
    }

    public function show(\App\Models\Invoice $invoice): \Illuminate\View\View
    {
        $invoice->load(['lines', 'cuentaContable', 'cuentaAbono', 'client']);

        // Block C: if this is a payment complement, load the documents it settles.
        $paymentLinks = collect();
        if ($invoice->tipo_comprobante === 'P' && class_exists(\App\Models\PaymentDocument::class)) {
            $paymentLinks = \App\Models\PaymentDocument::where('payment_invoice_id', $invoice->id)
                ->with('paidInvoice')
                ->get();
        }

        // If this invoice is itself paid by complements, show which payments cleared
        // it (the reverse direction — useful on an income invoice).
        $paidByLinks = collect();
        if (in_array($invoice->tipo_comprobante, ['I', 'E'], true) && class_exists(\App\Models\PaymentDocument::class)) {
            $paidByLinks = \App\Models\PaymentDocument::where('client_id', $invoice->client_id)
                ->where('iddocumento', $invoice->uuid)
                ->with('paymentInvoice')
                ->get();
        }

        return view('invoices.show', [
            'invoice'      => $invoice,
            'paymentLinks' => $paymentLinks,
            'paidByLinks'  => $paidByLinks,
        ]);
    }

    /** Download the original XML, verbatim (SAT compliance). */
    public function xml(Invoice $invoice)
    {
        abort_if(! $invoice->xml_original, 404, 'XML no disponible.');

        return Response::make($invoice->xml_original, 200, [
            'Content-Type'        => 'application/xml',
            'Content-Disposition' => 'attachment; filename="' . $invoice->uuid . '.xml"',
        ]);
    }
}
