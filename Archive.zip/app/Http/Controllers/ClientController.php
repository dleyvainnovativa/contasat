<?php

namespace App\Http\Controllers;

use App\Models\Client;
use App\Services\CertificateParser;
use App\Services\WorkContext;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\View\View;

class ClientController extends Controller
{
    public function __construct(
        private readonly WorkContext $context,
        private readonly CertificateParser $certs,
    ) {}

    public function index(Request $request): View|RedirectResponse
    {
        // When a client is active, the clients page jumps straight to that
        // client's detail (#3). `?all=1` escapes to the full list.
        if ($this->context->hasClient() && ! $request->boolean('all')) {
            return redirect()->route('clients.show', $this->context->client());
        }

        $clients = Client::query()
            ->search($request->string('q')->toString() ?: null)
            ->when($request->filled('estado'), function ($q) use ($request) {
                $q->where('activo', $request->string('estado') === 'activos');
            })
            ->orderBy('razon_social')
            ->paginate(20)
            ->withQueryString();

        return view('clients.index', [
            'clients' => $clients,
            'q'       => $request->string('q')->toString(),
            'estado'  => $request->string('estado')->toString(),
        ]);
    }

    public function create(): View
    {
        return view('clients.create', ['client' => new Client()]);
    }

    public function store(Request $request): RedirectResponse
    {
        $data = $this->validated($request);

        $client = Client::create($data);

        // The client's receivable subaccount (105.01.#) is no longer minted here.
        // It's created lazily on the first póliza de provisión, via
        // CounterpartyAccountService, keyed on the invoice's RFC.

        // Selecting a freshly created client as the active one is a natural next step.
        $this->context->setClient($client);

        return redirect()
            ->route('clients.show', $client)
            ->with('toast', ['type' => 'success', 'message' => 'Cliente creado.']);
    }

    public function show(Client $client): View
    {
        $client->load(['periods' => fn($q) => $q->orderByDesc('year')->orderByDesc('month')]);

        return view('clients.show', ['client' => $client]);
    }

    public function edit(Client $client): View
    {
        return view('clients.edit', ['client' => $client]);
    }

    public function update(Request $request, Client $client): RedirectResponse
    {
        $client->update($this->validated($request, $client));

        return redirect()
            ->route('clients.show', $client)
            ->with('toast', ['type' => 'success', 'message' => 'Cliente actualizado.']);
    }

    public function destroy(Client $client): RedirectResponse
    {
        $client->delete();

        return redirect()
            ->route('clients.index')
            ->with('toast', ['type' => 'success', 'message' => 'Cliente archivado.']);
    }

    /** Set this client as the active working context (used by the client switcher). */
    public function activate(Request $request, Client $client): RedirectResponse|JsonResponse
    {
        $this->context->setClient($client);

        if ($request->expectsJson()) {
            return response()->json(['ok' => true, 'client' => $client->only(['id', 'rfc', 'razon_social'])]);
        }

        return back()->with('toast', ['type' => 'success', 'message' => "Cliente activo: {$client->display_name}"]);
    }

    /** Shared validation for store + update. */
    private function validated(Request $request, ?Client $client = null): array
    {
        // The form's <input type="month"> submits "YYYY-MM"; store it as the first
        // day of that month so it validates and casts as a date.
        if ($request->filled('inicio_operaciones') && preg_match('/^\d{4}-\d{2}$/', $request->input('inicio_operaciones'))) {
            $request->merge(['inicio_operaciones' => $request->input('inicio_operaciones') . '-01']);
        }

        $data = $request->validate([
            'rfc' => [
                'required',
                'string',
                'max:13',
                Rule::unique('clients', 'rfc')->ignore($client?->id),
            ],
            'razon_social'     => ['required', 'string', 'max:255'],
            'nombre_comercial' => ['nullable', 'string', 'max:255'],
            'regimen_fiscal'   => ['required', Rule::in(['fisica', 'moral'])],
            'codigo_postal'    => ['nullable', 'string', 'size:5'],
            // Inicio de operaciones: month/year the client began. Must be the
            // current month or earlier — never a future period. The form submits
            // the first day of the month; we validate it's not after today.
            'inicio_operaciones' => ['nullable', 'date', 'before_or_equal:today'],
            'email'            => ['nullable', 'email', 'max:255'],
            'telefono'         => ['nullable', 'string', 'max:30'],
            'activo'           => ['sometimes', 'boolean'],
            'notas'            => ['nullable', 'string'],
            // Certificate expiry: a manual date, and/or a .cer whose date wins.
            'efirma_expira'    => ['nullable', 'date'],
            'csd_expira'       => ['nullable', 'date'],
            'efirma_cer'       => ['nullable', 'file', 'max:20'],   // KB; SAT .cer is ~1–2 KB
            'csd_cer'          => ['nullable', 'file', 'max:20'],
        ]);

        // Parse any uploaded .cer and let its expiry/serial override the manual
        // date. Unparseable files are ignored so a bad upload never blocks a save.
        foreach ([
            ['efirma_cer', 'efirma_expira', 'efirma_serial'],
            ['csd_cer', 'csd_expira', 'csd_serial'],
        ] as [$fileKey, $dateKey, $serialKey]) {
            if ($request->hasFile($fileKey)) {
                $parsed = $this->certs->parse($request->file($fileKey)->getRealPath());
                if ($parsed['expira']) {
                    $data[$dateKey]   = $parsed['expira']->toDateString();
                    $data[$serialKey] = $parsed['serial'];
                }
            }
        }

        // The file inputs aren't columns.
        unset($data['efirma_cer'], $data['csd_cer']);

        return $data;
    }
}
